export interface Product {
    id: number
    artistName: string
    albumName: string
}
