export interface Track {
    trackNumber: number
    trackName: string
    trackLength: string
    trackPrice: number
}
